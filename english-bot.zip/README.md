# english-bot
This is just a normal bot in telegram that gives you oppotunity to learn english by the questions!
